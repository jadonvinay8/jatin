package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Response;
import com.cg.service.OrderServices;



@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping(value = "/placeorder")
public class PlacedController {

	@Autowired
	OrderServices service;

	@GetMapping(value = "/placingorder/{userId}")
	public Response placeOrder(@PathVariable int userId) {
		String temp =  service.checkProducts(userId);
		if(temp.equals("Success")) {
			return new Response(200, temp, null);
		}else {
			return new Response(400, temp, null);
		}
	}

	@PutMapping(value = "/payment/{modeOfPurchase}/{userId}")
	public Response getPayment(@PathVariable int userId, @PathVariable String modeOfPurchase) {
		return service.updateInventory(userId, modeOfPurchase);
	}

}
