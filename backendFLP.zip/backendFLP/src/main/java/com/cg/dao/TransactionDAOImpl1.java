package com.cg.dao;



import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.bean.Transaction;

@Repository
public class TransactionDAOImpl1 implements TransactionDAO1 {

	@PersistenceContext
	EntityManager em;

	@Override
	public int useridorder(int orderid) {
		String query = "select t.user.userId from Transaction t where t.transactionId = :transid";
		Query q = em.createQuery(query);
		q.setParameter("transid", orderid);
		int userid = (int) q.getSingleResult();
		return userid;
	}

	@SuppressWarnings("unchecked")
	public List<Integer> productidorder(int orderid) {
		String query = "select t from Transaction t where t.transactionId = : transid";
		TypedQuery<Transaction> q = (TypedQuery<Transaction>) em.createQuery(query);
		q.setParameter("transid", orderid);
		Transaction t = q.getSingleResult();
		List<Integer[]> list = t.getProducts();
		List<Integer> listint = new ArrayList<Integer>();
		for (int i = 0; i < list.size(); i++) {
			int productid = list.get(i)[0];
			listint.add(productid);
		}
		return listint;
	}

	@SuppressWarnings("unchecked")
	public int productquantityorder(int orderid) {
		String query = "select t from Transaction t where t.transactionId = : transid";
		TypedQuery<Transaction> q = (TypedQuery<Transaction>) em.createQuery(query);
		q.setParameter("transid", orderid);
		Transaction t = q.getSingleResult();
		List<Integer[]> list = t.getProducts();
		int productquantity = list.get(0)[1];
		return productquantity;
	}

	@SuppressWarnings("unchecked")
	public Transaction getTransaction(int orderid) {
		String query = "select t from Transaction t where t.transactionId = : transid";
		TypedQuery<Transaction> q = (TypedQuery<Transaction>) em.createQuery(query);
		q.setParameter("transid", orderid);
		Transaction t = q.getSingleResult();
		return t;
	}

	@SuppressWarnings("unchecked")
	public Date dateorder(int orderid) {
		String query = "select t from Transaction t where t.transactionId = : transid";
		TypedQuery<Transaction> q = (TypedQuery<Transaction>) em.createQuery(query);
		q.setParameter("transid", orderid);
		Transaction t = q.getSingleResult();
		Date list = t.getDateOfPurchase();
		return list;
	}

}
