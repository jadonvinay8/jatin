package com.cg.service;

import java.sql.Date;
import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.SocketUtils;

import com.cg.bean.Cart;
import com.cg.bean.Product;
import com.cg.bean.Transaction;
import com.cg.bean.User1;
import com.cg.dao.CartDAO;
import com.cg.dao.ProductDAO;
import com.cg.dao.TransactionDAO;
import com.cg.dao.User1DAO;
import com.cg.exception.ApplicationException;
import com.cg.model.Response;

@Service
@Transactional
public class OrderServicesImpl implements OrderServices {

	@Autowired
	ProductDAO placeDao;

	@Autowired
	TransactionDAO transactDao;

	@Autowired
	CartDAO cartDao;
	
	@Autowired
	User1DAO userDao;

	public Product findByProductId(int pid) {

		Optional<Product> product = placeDao.findById(pid);
		if (product.isPresent()) {
			return product.get();
		} else {
			throw new ApplicationException("No Product Exists");
		}
	}

	public Cart findByCartId(int cartID) {

		Optional<Cart> cart = cartDao.findById(cartID);
		if (cart.isPresent()) {
			return cart.get();
		} else {
			throw new ApplicationException("No Cart Exists");
		}
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public String checkProducts(int userId) {
		User1 user=null;
		try {
			 user=userDao.findByuserId(userId);
		}catch(ApplicationException e){
			throw new ApplicationException("No User Present");
		}
		Cart cart = cartDao.findByuser(user);
		
		boolean status = false;
		List<Product> products = cart.getProducts();
		String msg="";
		String msg1="";
		for (Product p : products) {
			int pid = p.getProductID();
			
			Product product = findByProductId(pid);

			int quantity = product.getQuantity();
			if (quantity >0 ) {
				status = true;
				msg1="Success";
				continue;
			} else
				status = false;
				msg=product.getProductName()+" is out of Stock with "+product.getQuantity();
				break;
		}
		
		if (status)
			return msg1;
		else
			return msg;
	}
	
	@Transactional(propagation = Propagation.REQUIRED)
	public boolean updateProducts(int pid, int cart_quantity) {
		try {
			placeDao.updateProducts(pid, cart_quantity);
		} catch (ApplicationException e) {
			throw new ApplicationException("Can't Update");
		}
		return true;
	}


	@Transactional(propagation = Propagation.REQUIRED)
	public Response updateInventory(int userId, String modeOfPurchase) {
		User1 user=userDao.findByuserId(userId);
		
		Cart cart = cartDao.findByuser(user);
		
		List<Product> products = cart.getProducts();
		List<Double> amounts = new ArrayList<>(cart.getAmount());
		boolean updateStatus = false;
		for (Product p : products) {
			int pid = p.getProductID();
			int quantity=1;
			updateStatus=updateProducts(pid, quantity);
		}
		
		List<Product> products1 = new ArrayList<Product>();
		products1.addAll(products);
		
		if (updateStatus) {
			
			String status = "Ordered";
			java.util.Date date = new java.util.Date();
			Date dateOfPurchase = new Date(date.getYear(), date.getMonth(), date.getDate());

			Transaction transaction = new Transaction();
			transaction.setUser(user);
			
			List<Integer[]> orders = new ArrayList<>();
			int index = 0;
			for(Product product : products1) {
				Integer[] element = {product.getProductID(), 1, Integer.parseInt(amounts.get(index).toString().substring(0, amounts.get(index).toString().indexOf(".")))};	
				orders.add(element);
				System.out.println(element);
				System.out.println(orders.toString());
			}
			
			transaction.setProducts(orders);
			
			
//			transaction.setProducts(products1);
			transaction.setStatus(status);
			transaction.setDateOfPurchase(dateOfPurchase);
			transaction.setModeOfPurchase(modeOfPurchase);

			System.out.println(transaction);
			transactDao.saveAndFlush(transaction);
	
			Integer tid = transaction.getTransactionId();
			
			return new Response(200, tid.toString(), null);
		} else {
			return new Response(400, "Error", null);
		}
		
	}
	
}
